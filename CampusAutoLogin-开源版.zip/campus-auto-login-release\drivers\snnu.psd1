﻿# ============================================================
#  认证驱动：陕西师范大学（SNNU Portal）
# ------------------------------------------------------------
#  驱动 = 描述"某个学校的校园网门户长什么样、怎么登录"的一个数据文件。
#  想适配别的学校，照着 generic.psd1 复制一份改字段即可，不用改主脚本。
# ============================================================
@{
    name        = 'snnu'
    displayName = '陕西师范大学（SNNU Portal）'
    notes       = '认证服务器 202.117.144.205，端口 8603 / 8602 / 8601'

    # -------- 门户探测：TCP 连这些端口，能连上说明在校园网内、可以认证 --------
    probeHost  = '202.117.144.205'
    probePorts = @(8603, 8602, 8601)

    # -------- 运营商映射：config.psd1 里的 carrier -> 提交给门户的 yys --------
    carriers = @{
        unicom  = 'unicom'    # 中国联通
        mobile  = 'mobile'    # 中国移动
        telecom = 'telecom'   # 中国电信
        campus  = ''          # 校园网（默认出口）
    }

    # -------- 登录请求 --------
    # 可用的占位符：{host} {port} {account} {password} {carrier}
    login = @{
        urlTemplate = 'http://{host}:{port}/snnuportal/login'
        method      = 'POST'
        fields      = @{
            sourceurl = 'null'
            account   = '{account}'
            password  = '{password}'
            yys       = '{carrier}'
            issave    = ''
        }
    }

    # -------- 断开请求（仅"强制重连 -ForceLogin"时使用）--------
    logoff = @{
        urlTemplate = 'http://{host}:{port}/snnuportal/logoff'
        method      = 'POST'
    }
}
