﻿# ============================================================
#  认证驱动：通用"表单 POST"门户模板
# ------------------------------------------------------------
#  国内很多高校的校园网 Web 门户，本质上就是"往某个地址 POST 一张表单"。
#  用法：
#    1) 把本文件复制成  drivers\我的学校.psd1
#    2) 在 config.psd1 里把 driver 改成 '我的学校'
#    3) 打开浏览器 F12 -> 网络(Network)，正常登录一次，找到那个登录请求，
#       把它的地址、方法、表单字段抄到下面即可。
#
#  怎么判断"登录成功了"：脚本不看你抄的返回值，而是用"能不能上外网"来验证，
#  所以只要地址和字段抄对，一般就能用。
# ============================================================
@{
    name        = 'generic'
    displayName = '通用表单门户（模板，请按需修改）'
    notes       = '把下面的地址和字段改成你学校的即可'

    # -------- 门户探测 --------
    # 留空表示用 config.psd1 里的 portalHost / portalPorts
    probeHost  = ''
    probePorts = @(80)

    carriers = @{
        campus  = ''
        unicom  = 'unicom'
        mobile  = 'mobile'
        telecom = 'telecom'
    }

    # -------- 登录请求（重点改这里）--------
    login = @{
        # 例：http://10.0.0.1/login      或  http://portal.xxx.edu.cn:8080/do_login
        urlTemplate = 'http://{host}:{port}/login'
        method      = 'POST'
        fields      = @{
            # 左边是门户要求的字段名，右边是取值（可用占位符）
            username = '{account}'
            password = '{password}'
            # 有些门户还要运营商/域字段，例如：
            # domain = '{carrier}'
        }
    }

    # -------- 断开请求（没有就留空或删掉）--------
    logoff = @{
        urlTemplate = 'http://{host}:{port}/logout'
        method      = 'POST'
    }
}
