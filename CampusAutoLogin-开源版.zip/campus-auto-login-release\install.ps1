﻿<#
=====================================================================
 校园网自动登录 - 一键安装
 --------------------------------------------------------------------
 作用：为当前 Windows 用户注册「校园网自动登录」计划任务
 用法：
   1) 先改好同目录 config.psd1（账号 / 密码 / 运营商）
   2) 双击 install.cmd（或右键 install.ps1 → 使用 PowerShell 运行）
 说明：无需管理员权限；重复运行会自动覆盖旧任务。
=====================================================================
#>
[CmdletBinding()]
param(
    [switch]$NoTest
)

$ErrorActionPreference = 'Stop'
$TaskName = 'CampusAutoLogin'
$LegacyTaskName = 'SNNU-CampusAutoLogin'   # 旧版本的任务名，安装时顺手清理
$dir  = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$ps1  = Join-Path $dir 'campus-login.ps1'
$vbs  = Join-Path $dir 'run-hidden.vbs'
$cfgP = Join-Path $dir 'config.psd1'

Write-Host '==============================================' -ForegroundColor Cyan
Write-Host '        校园网自动登录 - 安装' -ForegroundColor Cyan
Write-Host '==============================================' -ForegroundColor Cyan

# ---------- 检查必需文件 ----------
$missing = @()
foreach ($f in @($ps1, $vbs)) { if (-not (Test-Path -LiteralPath $f)) { $missing += $f } }
if ($missing.Count -gt 0) {
    Write-Host ('缺少文件：' + ($missing -join ', ')) -ForegroundColor Red
    exit 1
}

# ---------- 读取并显示配置 ----------
$cfg = $null
if (Test-Path -LiteralPath $cfgP) {
    try { $cfg = Import-PowerShellDataFile -LiteralPath $cfgP }
    catch { Write-Host ('config.psd1 读取失败：' + $_.Exception.Message) -ForegroundColor Yellow }
}
$driver = $null
if ($cfg) {
    $carrierName = switch ("$($cfg.carrier)") {
        'unicom'  { '中国联通' }
        'mobile'  { '中国移动' }
        'telecom' { '中国电信' }
        default   { '校园网(默认出口)' }
    }
    $drvHost = ''
    $drvFile = Join-Path $dir ("drivers\{0}.psd1" -f $cfg.driver)
    if (Test-Path -LiteralPath $drvFile) {
        try { $driver = Import-PowerShellDataFile -LiteralPath $drvFile; $drvHost = [string]$driver.probeHost } catch { }
    }
    $hostShown = if ("$($cfg.portalHost)" -ne '') { [string]$cfg.portalHost } else { $drvHost }
    Write-Host ("账号     : {0}" -f $cfg.account)
    Write-Host ("运营商   : {0}" -f $carrierName)
    Write-Host ("驱动     : {0}" -f $cfg.driver)
    if ($hostShown) { Write-Host ("认证地址 : http://{0}" -f $hostShown) }
} else {
    Write-Host '警告：未读到 config.psd1，脚本将使用内置默认配置。' -ForegroundColor Yellow
}
Write-Host ("安装目录 : {0}" -f $dir)
Write-Host ''

# ---------- 触发器：只在登录 Windows 时运行一次 ----------
# 刻意不使用"网络连接 / 掉网"等事件触发：
# 那类触发会在使用过程中反复拉起进程，全屏游戏时会闪现命令行窗口。
# 现在使用过程中不运行任何东西，因此不可能出现弹窗。
$user = '{0}\{1}' -f $env:USERDOMAIN, $env:USERNAME
$triggers = @(New-ScheduledTaskTrigger -AtLogOn -User $user)

$action    = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ('"{0}"' -f $vbs)
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
                -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -MultipleInstances IgnoreNew
$settings.Hidden = $true

try {
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Principal $principal -Settings $settings `
        -Description '校园网自动登录（仅在登录 Windows 时认证一次，使用中不运行）' -Force | Out-Null
    Write-Host '计划任务注册成功。' -ForegroundColor Green
    if ($LegacyTaskName -and (Get-ScheduledTask -TaskName $LegacyTaskName -ErrorAction SilentlyContinue)) {
        Unregister-ScheduledTask -TaskName $LegacyTaskName -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host ('已清理旧任务：' + $LegacyTaskName) -ForegroundColor DarkGray
    }
} catch {
    Write-Host ('计划任务注册失败：' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

# ---------- 睡眠唤醒 / 保活：生成 wake.ini 并注册配套任务 ----------
# 这一套完全用 wscript + WinHttp 实现（不启动 PowerShell），所以零控制台、零弹窗。
$wakeTaskName = 'CampusAutoLogin-Wake'
$wakeVbs  = Join-Path $dir 'wake-login.vbs'
$wakeIni  = Join-Path $dir 'wake.ini'

$enableWake = $true
if ($null -ne $cfg -and $null -ne $cfg.enableWakeRecovery) { $enableWake = [bool]$cfg.enableWakeRecovery }
$keepMin = 0
if ($null -ne $cfg -and $cfg.keepAliveMinutes) { $keepMin = [int]$cfg.keepAliveMinutes }

# 先清掉旧的唤醒任务，按最新配置重建
Unregister-ScheduledTask -TaskName $wakeTaskName -Confirm:$false -ErrorAction SilentlyContinue

if ((Test-Path -LiteralPath $wakeVbs) -and $cfg -and $cfg.account -and $driver) {
    # --- 生成 wake.ini（纯 ASCII，供 VBS 读取）---
    $pH = if ("$($cfg.portalHost)" -ne '') { [string]$cfg.portalHost } else { [string]$driver.probeHost }
    $pPorts = @()
    if (@($cfg.portalPorts).Count -gt 0) { $pPorts = @($cfg.portalPorts) } else { $pPorts = @($driver.probePorts) }
    $cVal = [string]$cfg.carrier
    if ($driver.carriers -and $driver.carriers.ContainsKey([string]$cfg.carrier)) { $cVal = [string]$driver.carriers[[string]$cfg.carrier] }

    $loginUrls = @()
    foreach ($pp in $pPorts) {
        $u = [string]$driver.login.urlTemplate
        $u = $u.Replace('{host}', $pH).Replace('{port}', [string]$pp)
        $u = $u.Replace('{account}', [uri]::EscapeDataString([string]$cfg.account))
        $u = $u.Replace('{password}', [uri]::EscapeDataString([string]$cfg.password))
        $u = $u.Replace('{carrier}', [uri]::EscapeDataString($cVal))
        $loginUrls += $u
    }

    $pairs = @()
    foreach ($k in $driver.login.fields.Keys) {
        $v = [string]$driver.login.fields[$k]
        $v = $v.Replace('{account}', [string]$cfg.account).Replace('{password}', [string]$cfg.password)
        $v = $v.Replace('{carrier}', $cVal).Replace('{host}', $pH)
        $pairs += ([uri]::EscapeDataString([string]$k) + '=' + [uri]::EscapeDataString($v))
    }

    $iniLines = @(
        '# generated by install.ps1 - do not edit',
        'probeUrls=https://www.baidu.com|https://www.taobao.com|http://www.msftconnecttest.com/connecttest.txt|http://connectivitycheck.gstatic.com/generate_204',
        ('loginUrls=' + ($loginUrls -join '|')),
        ('loginBody=' + ($pairs -join '&'))
    )
    Set-Content -LiteralPath $wakeIni -Value $iniLines -Encoding ASCII

    # --- 按配置注册唤醒 / 保活任务 ---
    if ($enableWake -or $keepMin -gt 0) {
        $wTriggers = @()
        if ($enableWake) {
            $subWake = '<QueryList><Query Id="0" Path="System"><Select Path="System">*[System[Provider[@Name=''Microsoft-Windows-Kernel-Power''] and (EventID=107)]]</Select></Query></QueryList>'
            $evc = Get-CimClass -ClassName MSFT_TaskEventTrigger -Namespace 'Root/Microsoft/Windows/TaskScheduler'
            $evt = New-CimInstance -CimClass $evc -ClientOnly
            $evt.Enabled = $true
            $evt.Subscription = $subWake
            $wTriggers += $evt
        }
        if ($keepMin -gt 0) {
            $wTriggers += New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
                -RepetitionInterval (New-TimeSpan -Minutes $keepMin) -RepetitionDuration (New-TimeSpan -Days 3650)
        }
        $wAction   = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument ('"{0}"' -f $wakeVbs)
        $wSettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
                        -ExecutionTimeLimit (New-TimeSpan -Minutes 3) -MultipleInstances IgnoreNew
        $wSettings.Hidden = $true
        Register-ScheduledTask -TaskName $wakeTaskName -Action $wAction -Trigger $wTriggers -Principal $principal `
            -Settings $wSettings -Description '睡眠唤醒后自动重连校园网（零弹窗）' -Force | Out-Null
        $extra = ''
        if ($keepMin -gt 0) { $extra = '（保活间隔 ' + $keepMin + ' 分钟）' }
        Write-Host ('睡眠唤醒重连：已启用' + $extra) -ForegroundColor Green
    } else {
        Write-Host '睡眠唤醒重连：已关闭（enableWakeRecovery=false 且 keepAliveMinutes=0）' -ForegroundColor DarkGray
    }
} else {
    Write-Host '跳过唤醒重连配置（缺少 wake-login.vbs 或账号/驱动信息）' -ForegroundColor Yellow
}

# ---------- 立即测试一次 ----------
if (-not $NoTest) {
    Write-Host '正在测试运行一次 ...' -ForegroundColor Cyan
    Start-ScheduledTask -TaskName $TaskName
    Start-Sleep -Seconds 10
    $info = Get-ScheduledTaskInfo -TaskName $TaskName
    Write-Host ("运行结果码: {0}   (0 = 成功)" -f $info.LastTaskResult)
    $log = Join-Path $dir 'logs\campus-login.log'
    if (Test-Path -LiteralPath $log) {
        Write-Host '最近日志：' -ForegroundColor Cyan
        Get-Content -LiteralPath $log -Encoding UTF8 -Tail 5 | ForEach-Object { Write-Host ('  ' + $_) }
    }
}

Write-Host ''
Write-Host '安装完成！登录 Windows 时自动认证一次；睡眠唤醒后由独立任务静默重连（零弹窗）。' -ForegroundColor Green
Write-Host '手动测试：双击 run-login.cmd        卸载：双击 uninstall.cmd' -ForegroundColor Green
