﻿<#
=====================================================================
 gui-run.ps1 —— 图形界面调用包装器
 --------------------------------------------------------------------
 作用：强制本进程的 stdout 使用 UTF-8 输出。
 背景：PowerShell 在输出被重定向到文件时，默认使用系统 ANSI 编码（中文系统为 GBK），
       而图形界面按 UTF-8 读取，就会导致中文乱码。先在这里把编码统一成 UTF-8 即可解决。
 由 gui.ps1 调用：powershell -File gui-run.ps1 -Target <要执行的脚本>
=====================================================================
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Target
)

try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch { }
try { $OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch { }
$global:OutputEncoding = $OutputEncoding

if (-not (Test-Path -LiteralPath $Target)) {
    Write-Output ('找不到脚本：' + $Target)
    exit 1
}

& $Target
exit $LASTEXITCODE
