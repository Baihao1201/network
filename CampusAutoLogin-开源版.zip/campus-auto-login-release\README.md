# 校园网自动登录（Windows · 通用驱动式）

**只在登录 Windows 时**自动完成一次校园网 Web Portal 认证。
使用过程中（打游戏、看视频等）**不运行任何后台程序、不弹任何窗口**。
有线与 WiFi 都支持且不限定 SSID，笔记本同样适用。

> ✅ 已在 **陕西师范大学（SNNU）** 实测通过。
> 🔧 其它学校：往 `drivers/` 放一个"驱动"文件即可适配，**不用改代码**。

[English](README_EN.md) | 中文

---

## 一、特性

| 能力 | 说明 |
|---|---|
| **触发时机** | 登录 Windows 时；**可选**睡眠唤醒后（使用中不运行，零弹窗） |
| **够快** | 用原始 TCP 探测判断网络状态（**不做 DNS 解析**），离线判定约 25 ms 级；从网络就绪到认证成功约 1～3 秒 |
| **够静** | 通过 VBS 隐藏窗口启动，不弹 PowerShell 窗口 |
| **睡眠唤醒** | 可选：唤醒后自动重连，VBScript + WinHttp 实现，**零控制台窗口**（实测 conhost 增量 0） |
| **够稳** | 以"**能否真的上外网**"作为唯一成功标准，而不是看网页返回值 |
| **好迁移** | 账号密码等放在独立配置文件；一键安装 / 一键卸载；无需管理员权限 |
| **可扩展** | 门户的"地址 / 字段 / 运营商映射"全部写在数据文件（驱动）里 |
| **有界面** | 自带图形配置工具，可视化填账号、测试、安装 |

纯 PowerShell 5.1 实现，依赖仅系统自带的 `curl.exe`，**不需要 Python 或任何第三方库**。

---

## 二、快速开始（3 步）

1. 把 `config.example.psd1` 复制为 `config.psd1`，填写账号 / 密码 / 运营商。
2. 双击 **`gui.cmd`**（图形界面，推荐）或 `install.cmd`（命令行）。
3. 完成。之后每次登录 Windows 都会自动认证一次，使用过程中不会再运行。

> 无需管理员权限。给同学用：整个文件夹拷过去 → 改 `config.psd1` → 双击 `gui.cmd` 点"安装"即可。

---

## 三、图形界面

双击 `gui.cmd`，可以：

- 填写并保存账号、密码、运营商、学校（驱动）、可选的门户地址/端口；
- **测试登录**（立即跑一次，输出显示在下方）；
- **安装 / 更新计划任务**、**卸载任务**；
- 一键打开日志、打开文件夹。

---

## 四、适配别的学校（开源重点）

校园网门户五花八门，但"请求长什么样"是可以数据化描述的。本项目把这件事抽成了**驱动**：

### 4.1 驱动是什么

`drivers/<名称>.psd1`，就是一个纯数据文件：

```powershell
@{
    name        = 'snnu'
    displayName = '陕西师范大学（SNNU Portal）'
    probeHost   = '202.117.144.205'      # 门户地址
    probePorts  = @(8603, 8602, 8601)    # 门户端口（按优先级）
    carriers    = @{ unicom='unicom'; mobile='mobile'; telecom='telecom'; campus='' }
    login       = @{
        urlTemplate = 'http://{host}:{port}/snnuportal/login'
        method      = 'POST'
        fields      = @{
            sourceurl = 'null'
            account   = '{account}'
            password  = '{password}'
            yys       = '{carrier}'
            issave    = ''
        }
    }
    logoff      = @{ urlTemplate = 'http://{host}:{port}/snnuportal/logoff'; method='POST' }
}
```

占位符 `{host} {port} {account} {password} {carrier}` 会在运行时被替换。

### 4.2 怎么给自己的学校写一个

1. 复制 `drivers/generic.psd1` → `drivers/我的学校.psd1`；
2. 浏览器打开校园网登录页，按 `F12` → **网络(Network)**，正常登录一次，
   找到那个登录请求，把它的 **地址、方法、表单字段** 抄进驱动；
3. `config.psd1` 里把 `driver` 改成 `'我的学校'`，安装即可。

因为脚本是**用"能不能上网"来判定成功**的，所以只要你抄的请求本身是对的，就能工作；
即使门户返回什么状态码、跳转到哪个页面都不影响。

> 目前 `snnu` 驱动是作者实测有效的；其余常见门户类型（深澜 Srun、Dr.COM、锐捷等）
> 欢迎按上面的方法做成驱动并 PR 回本项目。

---

## 五、配置说明（config.psd1）

```powershell
account  = '你的学号'
password = '你的密码'
carrier  = 'unicom'          # unicom=联通  mobile=移动  telecom=电信  campus=校园网
driver   = 'snnu'            # 用哪个驱动

portalHost  = ''             # 可选覆盖，留空用驱动默认
portalPorts = @()            # 可选覆盖，留空用驱动默认

internetProbeIps = @('223.5.5.5', '223.6.6.6')                    # TCP 快速探测（不依赖 DNS）
internetTargets  = @('https://www.baidu.com', 'https://www.taobao.com')  # HTTP 精确确认

waitReadySec       = 45      # 网络就绪后持续尝试的总时间窗口（秒）
tcpTimeoutMs       = 500     # 单次 TCP 探测超时（毫秒）
internetTimeoutSec = 4       # HTTP 外网确认超时（秒）
portalTimeoutSec   = 6       # 门户登录请求超时（秒）
loginRetryDelayMs  = 1500    # 两次登录尝试的最小间隔（毫秒）

enableWakeRecovery = $true   # 睡眠/休眠唤醒后自动重连（零弹窗、空闲无开销）
keepAliveMinutes   = 3       # 保活间隔(分钟)：3/5/10/20/30，0 = 关闭（GUI 下拉框可选）
```

> 改完保存即可，**无需重新安装**（计划任务每次运行都会重新读取配置）。

---

## 六、什么时候会运行

| 时机 | 说明 | 怎么跑 |
|---|---|---|
| **登录 Windows 时** | 认证一次 | PowerShell（隐藏） |
| **睡眠 / 休眠唤醒后**（可选） | 检测到掉线才重连 | **VBScript + WinHttp，零窗口** |

- 使用过程中（打游戏、看视频）**不会运行任何东西**：之前的"网络连接 / 掉网"事件触发已全部移除。
- 唤醒重连是**独立任务**，全程不启动 PowerShell、不创建控制台窗口（实测 conhost 增量为 **0**）。
- **默认开启保活（3 分钟）**：掉线后最多 3 分钟自动恢复。可在 GUI 的「**保活间隔**」下拉框选择
  **关闭 / 3 / 5 / 10 / 20 / 30 分钟**（对应 `keepAliveMinutes`），按需调整检查频率。
- 不需要唤醒功能：GUI 里取消勾选「睡眠唤醒后重连」，或 `enableWakeRecovery = $false`。
- **为什么"右下角显示有网、实际却不通"**：未认证时校园网关会对 HTTP 请求一律返回 `200 + 登录页`，
  Windows 的联网检测会被骗过。本程序用**严格探测**（204 状态码 / 响应内容校验）识别真实连通性，
  所以这种"假在线"也能被发现并自动重连。
- 手动补一次：双击 **`run-login.cmd`**。

---

## 七、为什么 WiFi 也能很快（技术说明）

早期版本在 WiFi 上要等十几秒甚至几十秒，根因有三：

1. **DNS 阻塞**：刚连上 WiFi 时 DNS 还没就绪，走域名的检测会卡在解析上（可达数秒），
   再乘以多个目标、多轮轮询，就是几十秒。
2. **外部进程开销**：每次检测都启动一个 `curl.exe`。
3. **轮询粒度粗**：1 秒一轮，网络就绪后要等下一轮才发现。

现在改为：

- **TCP 直达探测**：用 .NET `TcpClient` 连公网 IP 的 443 端口，**完全不碰 DNS**；
  在线时约 25 ms，离线时也只是一个短超时。
- **不做无谓判断**：一旦门户 TCP 可达，就**立即**发登录请求，不再先花时间探测外网。
- **细粒度循环**：250 ms 一轮，网络一就绪马上认证。
- **精确确认**：只有当快速探测显示"在线"时，才用一次 HTTP 请求做权威确认。

---

## 八、目录结构

```
campus-login.ps1        主脚本（通用，驱动式）
config.psd1             你的配置（已被 .gitignore 忽略，不会误传）
config.example.psd1     配置模板
drivers/snnu.psd1       陕西师范大学驱动（实测）
drivers/generic.psd1    通用表单门户模板
gui.ps1 / gui.cmd       图形配置工具
install.ps1 / .cmd      一键安装（注册计划任务）
uninstall.ps1 / .cmd    一键卸载
run-hidden.vbs          隐藏窗口启动器（不弹窗）
run-login.cmd           手动登录一次
logs/                   运行日志（已被忽略，超 512KB 自动截断）
LICENSE                 MIT 协议
```

---

## 九、常见问题

**Q：连了 WiFi 但上不了网？**
双击 `run-login.cmd` 手动跑一次，再看 `logs\campus-login.log`：
- "外网正常，已在线" → 其实已经通了；
- "正在登录…登录成功" → 正常；
- 一直没成功 → 检查 `config.psd1` 账号/密码/运营商，或驱动里的字段是否与门户一致。

**Q：怎么强制重连一次？**

```cmd
powershell -NoProfile -ExecutionPolicy Bypass -File "campus-login.ps1" -ForceLogin
```

**Q：怎么确认计划任务在跑？**

```powershell
Get-ScheduledTask -TaskName 'CampusAutoLogin' | Select State
Get-ScheduledTaskInfo -TaskName 'CampusAutoLogin' | Select LastRunTime, LastTaskResult
```

**Q：会不会泄露我的密码？**
密码明文存在本地 `config.psd1`（个人电脑常规做法）。该文件已在 `.gitignore` 中，
**不会**被提交到 Git 仓库；对外分发时请只发 `config.example.psd1`。

---

## 十、卸载

双击 `uninstall.cmd`，或：

```powershell
Unregister-ScheduledTask -TaskName 'CampusAutoLogin' -Confirm:$false
```

---

## 十一、开源协议

[MIT](LICENSE)　欢迎提交其它学校的驱动（`drivers/*.psd1`）与改进。
