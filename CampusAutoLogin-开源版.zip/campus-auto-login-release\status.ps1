﻿<#
=====================================================================
 校园网自动登录 - 状态 / 健康检查
 --------------------------------------------------------------------
 用途：随时确认「有没有后台在跑、占不占资源、最近工作是否正常」。
 双击 status.cmd 即可查看。
=====================================================================
#>
[CmdletBinding()]
param()

$Dir      = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$TaskName = 'CampusAutoLogin'
$LogPath  = Join-Path $Dir 'logs\campus-login.log'

Write-Host '========== 校园网自动登录 · 状态检查 ==========' -ForegroundColor Cyan
Write-Host ''

# ① 是否有脚本进程在跑
$selfPid = $PID
$procs = Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='wscript.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.ProcessId -ne $selfPid -and ($_.CommandLine -match 'campus-login\.ps1"' -or $_.CommandLine -like '*run-hidden.vbs*') }
if ($procs) {
    Write-Host '① 后台进程：检测到脚本正在运行（正在触发认证，属正常现象，几秒内自动结束）' -ForegroundColor Yellow
    $procs | ForEach-Object { Write-Host ('     PID={0}  {1}' -f $_.ProcessId, $_.Name) }
} else {
    Write-Host '① 后台进程：无  —— 程序不常驻，空闲时占用 0 CPU / 0 内存' -ForegroundColor Green
}

# ② 计划任务
$t = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($t) {
    Write-Host ('② 计划任务：{0}   状态={1}   触发器 {2} 个' -f $TaskName, $t.State, $t.Triggers.Count) -ForegroundColor Green
    Write-Host ('     超时上限={0}（到时强制结束）   多实例策略={1}' -f $t.Settings.ExecutionTimeLimit, $t.Settings.MultipleInstances)
    $i = Get-ScheduledTaskInfo -TaskName $TaskName
    Write-Host ('     上次运行={0}    返回码={1}' -f $i.LastRunTime, $i.LastTaskResult)
} else {
    Write-Host '② 计划任务：未安装（双击 gui.cmd 或 install.cmd 可安装）' -ForegroundColor Yellow
}

# ③ 触发频率与日志
if (Test-Path -LiteralPath $LogPath) {
    $lines  = Get-Content -LiteralPath $LogPath -Encoding UTF8
    $starts = @($lines | Where-Object { $_ -match '开始检测' })
    $sizeKB = [math]::Round((Get-Item -LiteralPath $LogPath).Length / 1KB, 1)
    Write-Host ('③ 累计运行 {0} 次    日志大小 {1} KB（超过 512KB 自动截断）' -f $starts.Count, $sizeKB)
    if ($starts.Count -gt 0) { Write-Host ('     最近一次：' + $starts[-1]) }
} else {
    Write-Host '③ 暂无运行日志'
}

# ④ 当前外网状态
$online = $false
foreach ($ip in @('223.5.5.5', '223.6.6.6')) {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $c.BeginConnect($ip, 443, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne(600, $false)) { $c.EndConnect($iar); $online = $true }
    } catch { } finally { try { $c.Close() } catch { } }
    if ($online) { break }
}
if ($online) { Write-Host '④ 当前外网：可以上网 ✓' -ForegroundColor Green }
else { Write-Host '④ 当前外网：不通（下次网络事件或手动 run-login.cmd 会自动重连）' -ForegroundColor Yellow }

Write-Host ''
Write-Host '说明：本程序没有任何常驻服务或后台守护进程。只有「登录 / 插网线 / 连 WiFi / 掉网」这些' -ForegroundColor DarkGray
Write-Host '      事件发生时，才临时启动一个 PowerShell 完成认证后立即退出；空闲时 CPU 与内存均为 0。' -ForegroundColor DarkGray
