﻿<#
=====================================================================
 校园网自动登录 - 图形配置工具（GUI）
 --------------------------------------------------------------------
 双击 gui.cmd 打开。功能：
   · 填写 / 保存账号、密码、运营商、学校（驱动）、门户地址
   · 一键测试登录、一键安装/更新计划任务、一键卸载
   · 查看运行日志
 纯 PowerShell + WinForms，无需安装任何依赖。
=====================================================================
#>
[CmdletBinding()]
param([switch]$SelfTest)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$Dir         = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$ConfigPath  = Join-Path $Dir 'config.psd1'
$ScriptPath  = Join-Path $Dir 'campus-login.ps1'
$InstallPath = Join-Path $Dir 'install.ps1'
$UninsPath   = Join-Path $Dir 'uninstall.ps1'
$LogPath     = Join-Path $Dir 'logs\campus-login.log'
$DriversDir  = Join-Path $Dir 'drivers'
$GuiRunPath  = Join-Path $Dir 'gui-run.ps1'

# ---------------------- 读取配置 ----------------------
$cfg = @{
    account = ''; password = ''; carrier = 'unicom'; driver = 'snnu'
    portalHost = ''; portalPorts = @()
    internetProbeIps = @('223.5.5.5', '223.6.6.6')
    internetTargets  = @('https://www.baidu.com', 'https://www.taobao.com')
    waitReadySec = 45; tcpTimeoutMs = 500; internetTimeoutSec = 4; portalTimeoutSec = 6; loginRetryDelayMs = 1500
}
if (Test-Path -LiteralPath $ConfigPath) {
    try {
        $u = Import-PowerShellDataFile -LiteralPath $ConfigPath -ErrorAction Stop
        if ($u) { foreach ($k in $u.Keys) { $cfg[$k] = $u[$k] } }
    } catch { }
}

# ---------------------- 扫描驱动 ----------------------
$driverNames = New-Object System.Collections.ArrayList
$driverTexts = New-Object System.Collections.ArrayList
if (Test-Path -LiteralPath $DriversDir) {
    Get-ChildItem -LiteralPath $DriversDir -Filter '*.psd1' -File | ForEach-Object {
        $n = [System.IO.Path]::GetFileNameWithoutExtension($_.Name)
        $label = $n
        try { $d = Import-PowerShellDataFile -LiteralPath $_.FullName; if ($d.displayName) { $label = "$n  —  $($d.displayName)" } } catch { }
        [void]$driverNames.Add($n)
        [void]$driverTexts.Add($label)
    }
}
if ($driverNames.Count -eq 0) { [void]$driverNames.Add('snnu'); [void]$driverTexts.Add('snnu') }

$carrierKeys  = @('unicom', 'mobile', 'telecom', 'campus')
$carrierTexts = @('中国联通', '中国移动', '中国电信', '校园网（默认出口）')

# ---------------------- 界面 ----------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = '校园网自动登录 · 配置工具'
$form.ClientSize = New-Object System.Drawing.Size(680, 620)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)

function Add-Label {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 110)
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $Text; $l.Location = New-Object System.Drawing.Point($X, $Y)
    $l.Size = New-Object System.Drawing.Size($W, 22); $l.TextAlign = 'MiddleRight'
    $form.Controls.Add($l); return $l
}

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = '校园网自动登录 · 配置工具'
$lblTitle.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 13, [System.Drawing.FontStyle]::Bold)
$lblTitle.Location = New-Object System.Drawing.Point(20, 12)
$lblTitle.Size = New-Object System.Drawing.Size(400, 30)
$form.Controls.Add($lblTitle)

# 账号
Add-Label '账号（学号）' 20 58 | Out-Null
$txtAccount = New-Object System.Windows.Forms.TextBox
$txtAccount.Location = New-Object System.Drawing.Point(140, 56)
$txtAccount.Size = New-Object System.Drawing.Size(220, 24)
$txtAccount.Text = [string]$cfg.account
$form.Controls.Add($txtAccount)

# 密码
Add-Label '密码' 20 92 | Out-Null
$txtPassword = New-Object System.Windows.Forms.TextBox
$txtPassword.Location = New-Object System.Drawing.Point(140, 90)
$txtPassword.Size = New-Object System.Drawing.Size(220, 24)
$txtPassword.UseSystemPasswordChar = $true
$txtPassword.Text = [string]$cfg.password
$form.Controls.Add($txtPassword)

$chkShowPwd = New-Object System.Windows.Forms.CheckBox
$chkShowPwd.Text = '显示'
$chkShowPwd.Location = New-Object System.Drawing.Point(368, 91)
$chkShowPwd.Size = New-Object System.Drawing.Size(60, 22)
$chkShowPwd.Add_CheckedChanged({ $txtPassword.UseSystemPasswordChar = -not $chkShowPwd.Checked })
$form.Controls.Add($chkShowPwd)

# 记住账号密码（方便他人：输一次，以后打开自动带出）
$chkRemember = New-Object System.Windows.Forms.CheckBox
$chkRemember.Text = '记住账号密码（仅存本机）'
$chkRemember.Location = New-Object System.Drawing.Point(432, 91)
$chkRemember.Size = New-Object System.Drawing.Size(232, 22)
$chkRemember.Checked = ([string]$cfg.account).Trim() -ne ''
$chkRemember.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($chkRemember)

# 运营商
Add-Label '运营商' 20 126 | Out-Null
$cbCarrier = New-Object System.Windows.Forms.ComboBox
$cbCarrier.Location = New-Object System.Drawing.Point(140, 124)
$cbCarrier.Size = New-Object System.Drawing.Size(220, 24)
$cbCarrier.DropDownStyle = 'DropDownList'
$cbCarrier.Items.AddRange($carrierTexts)
$ci = [Array]::IndexOf($carrierKeys, [string]$cfg.carrier); if ($ci -lt 0) { $ci = 0 }
$cbCarrier.SelectedIndex = $ci
$form.Controls.Add($cbCarrier)

# 驱动（学校）
Add-Label '学校 / 门户驱动' 20 160 | Out-Null
$cbDriver = New-Object System.Windows.Forms.ComboBox
$cbDriver.Location = New-Object System.Drawing.Point(140, 158)
$cbDriver.Size = New-Object System.Drawing.Size(500, 24)
$cbDriver.DropDownStyle = 'DropDownList'
$cbDriver.Items.AddRange($driverTexts.ToArray())
$di = $driverNames.IndexOf([string]$cfg.driver); if ($di -lt 0) { $di = 0 }
$cbDriver.SelectedIndex = $di
$form.Controls.Add($cbDriver)

$lblDriverHint = New-Object System.Windows.Forms.Label
$lblDriverHint.Text = '提示：换学校时，把新驱动放进 drivers\ 目录，这里就会出现。'
$lblDriverHint.ForeColor = [System.Drawing.Color]::Gray
$lblDriverHint.Location = New-Object System.Drawing.Point(140, 184)
$lblDriverHint.Size = New-Object System.Drawing.Size(500, 20)
$form.Controls.Add($lblDriverHint)

# 门户地址（可选）
Add-Label '门户地址（可选）' 20 212 | Out-Null
$txtHost = New-Object System.Windows.Forms.TextBox
$txtHost.Location = New-Object System.Drawing.Point(140, 210)
$txtHost.Size = New-Object System.Drawing.Size(220, 24)
$txtHost.Text = [string]$cfg.portalHost
$form.Controls.Add($txtHost)

Add-Label '端口（可选）' 370 212 90 | Out-Null
$txtPorts = New-Object System.Windows.Forms.TextBox
$txtPorts.Location = New-Object System.Drawing.Point(464, 210)
$txtPorts.Size = New-Object System.Drawing.Size(176, 24)
$txtPorts.Text = (@($cfg.portalPorts) -join ', ')
$form.Controls.Add($txtPorts)

$lblHostHint = New-Object System.Windows.Forms.Label
$lblHostHint.Text = '留空表示使用驱动里的默认地址 / 端口。'
$lblHostHint.ForeColor = [System.Drawing.Color]::Gray
$lblHostHint.Location = New-Object System.Drawing.Point(140, 236)
$lblHostHint.Size = New-Object System.Drawing.Size(500, 20)
$form.Controls.Add($lblHostHint)

# 按钮
function New-Button {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 118)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text; $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size($W, 32)
    $form.Controls.Add($b); return $b
}

$btnSave      = New-Button '保存配置' 20 272
$btnTest      = New-Button '测试登录' 146 272
$btnInstall   = New-Button '安装 / 更新任务' 272 272 150
$btnUninstall = New-Button '卸载任务' 430 272
$btnOpenLog   = New-Button '查看日志' 556 272

$btnOpenFolder = New-Button '打开文件夹' 20 312
$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = '就绪'
$lblStatus.Location = New-Object System.Drawing.Point(150, 318)
$lblStatus.Size = New-Object System.Drawing.Size(510, 22)
$lblStatus.ForeColor = [System.Drawing.Color]::DarkGreen
$form.Controls.Add($lblStatus)

$lblLogTitle = New-Object System.Windows.Forms.Label
$lblLogTitle.Text = '输出 / 日志：'
$lblLogTitle.Location = New-Object System.Drawing.Point(20, 348)
$lblLogTitle.Size = New-Object System.Drawing.Size(120, 20)
$form.Controls.Add($lblLogTitle)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(20, 370)
$txtLog.Size = New-Object System.Drawing.Size(640, 232)
$txtLog.Multiline = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.ReadOnly = $true
$txtLog.BackColor = [System.Drawing.Color]::White
$txtLog.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$form.Controls.Add($txtLog)

function Append-Log {
    param([string]$Text)
    if (-not $Text) { return }
    $txtLog.AppendText($Text.TrimEnd() + "`r`n")
}

function Set-Busy {
    param([bool]$Busy)
    $btnSave.Enabled      = -not $Busy
    $btnTest.Enabled      = -not $Busy
    $btnInstall.Enabled   = -not $Busy
    $btnUninstall.Enabled = -not $Busy
    $btnOpenLog.Enabled   = -not $Busy
    $btnOpenFolder.Enabled = -not $Busy
}

# ---------------------- 文本读取（防乱码）----------------------
# 优先按 UTF-8 解码；若检测到替换字符（说明不是 UTF-8），回退到系统 ANSI/GBK。
function Read-TextFile {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return '' }
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) { return '' }
    $utf8 = [System.Text.Encoding]::UTF8.GetString($bytes)
    if ($utf8.IndexOf([char]0xFFFD) -ge 0) {
        try { return ([System.Text.Encoding]::GetEncoding(936)).GetString($bytes) } catch { }
    }
    if ($utf8.Length -gt 0 -and $utf8[0] -eq [char]0xFEFF) { $utf8 = $utf8.Substring(1) }
    return $utf8
}

# ---------------------- 异步执行外部脚本 ----------------------
$script:proc   = $null
$script:outF   = Join-Path $env:TEMP ('campus-gui-out.txt')
$script:errF   = Join-Path $env:TEMP ('campus-gui-err.txt')
$script:action = ''

$script:timer = New-Object System.Windows.Forms.Timer
$script:timer.Interval = 400
$script:timer.Add_Tick({
    if ($script:proc -and $script:proc.HasExited) {
        $script:timer.Stop()
        foreach ($f in @($script:outF, $script:errF)) {
            $c = Read-TextFile -Path $f
            if ($c) { Append-Log $c }
        }
        $code = $script:proc.ExitCode
        Append-Log ('—— ' + $script:action + ' 结束，返回码 ' + $code + ' ——')
        if ($code -eq 0) { $lblStatus.Text = $script:action + ' 成功'; $lblStatus.ForeColor = [System.Drawing.Color]::DarkGreen }
        else { $lblStatus.Text = $script:action + ' 结束（返回码 ' + $code + '）'; $lblStatus.ForeColor = [System.Drawing.Color]::DarkOrange }
        Set-Busy $false
        $script:proc = $null
    }
})

function Start-PsFile {
    param([string]$File, [string]$ActionName)
    if ($script:proc) { return }
    if (-not (Test-Path -LiteralPath $File)) { Append-Log ('找不到文件：' + $File); return }
    if (-not (Test-Path -LiteralPath $GuiRunPath)) { Append-Log '找不到 gui-run.ps1，无法以 UTF-8 方式运行脚本。'; return }
    Remove-Item -LiteralPath $script:outF, $script:errF -ErrorAction SilentlyContinue
    # 经 gui-run.ps1 启动：它会把子进程输出统一为 UTF-8，避免中文乱码
    $argLine = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -Target "{1}"' -f $GuiRunPath, $File
    $script:action = $ActionName
    Append-Log ('—— ' + $ActionName + ' 开始 ——')
    $lblStatus.Text = $ActionName + ' 运行中 ...'
    $lblStatus.ForeColor = [System.Drawing.Color]::DarkBlue
    Set-Busy $true
    try {
        $script:proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $argLine `
            -RedirectStandardOutput $script:outF -RedirectStandardError $script:errF `
            -WindowStyle Hidden -PassThru
        $script:timer.Start()
    } catch {
        Append-Log ('启动失败：' + $_.Exception.Message)
        Set-Busy $false
        $script:proc = $null
    }
}

# ---------------------- 保存配置 ----------------------
function Save-Config {
    param([string]$Path = $ConfigPath)
    $acc = $txtAccount.Text.Trim()
    $pwd = $txtPassword.Text
    # 未勾选「记住账号密码」时，不把凭据写进配置文件（避免留在磁盘上）
    $saveAcc = $acc
    $savePwd = $pwd
    if (-not $chkRemember.Checked) { $saveAcc = ''; $savePwd = '' }
    $car = $carrierKeys[$cbCarrier.SelectedIndex]
    $drv = $driverNames[$cbDriver.SelectedIndex]
    $hst = $txtHost.Text.Trim()
    $prtRaw = $txtPorts.Text.Trim()
    $prtArr = @()
    if ($prtRaw) { $prtArr = @($prtRaw -split '[,，;\s]+' | Where-Object { $_ -ne '' }) }
    $prtText = if ($prtArr.Count -gt 0) { '@(' + ($prtArr -join ', ') + ')' } else { '@()' }

    $probeText   = '@(' + ((@($cfg.internetProbeIps)  | ForEach-Object { "'$_'" }) -join ', ') + ')'
    $targetLines = (@($cfg.internetTargets) | ForEach-Object { "        '$_'" }) -join ",`r`n"

    $text = @"
@{
    # ============================================================
    #  校园网自动登录 - 配置文件（由图形工具生成）
    #  改完保存即可，无需重新安装。
    # ============================================================

    # -------- 账号信息 --------
    account  = '$saveAcc'
    password = '$savePwd'
    carrier  = '$car'        # unicom=联通  mobile=移动  telecom=电信  campus=校园网

    # -------- 认证驱动（drivers\<名称>.psd1）--------
    driver = '$drv'

    # -------- 可选覆盖（留空 = 使用驱动默认值）--------
    portalHost  = '$hst'
    portalPorts = $prtText

    # -------- 外网判断参数 --------
    internetProbeIps = $probeText
    internetTargets  = @(
$targetLines
    )

    # -------- 时间参数 --------
    waitReadySec       = $($cfg.waitReadySec)
    tcpTimeoutMs       = $($cfg.tcpTimeoutMs)
    internetTimeoutSec = $($cfg.internetTimeoutSec)
    portalTimeoutSec   = $($cfg.portalTimeoutSec)
    loginRetryDelayMs  = $($cfg.loginRetryDelayMs)
}
"@
    Set-Content -LiteralPath $Path -Value $text -Encoding UTF8
    if ($Path -eq $ConfigPath) {
        $cfg.account = $saveAcc; $cfg.password = $savePwd; $cfg.carrier = $car; $cfg.driver = $drv
        $cfg.portalHost = $hst; $cfg.portalPorts = $prtArr
    }
}

# 运行前的校验：账号密码必须填写并勾选「记住」，否则计划任务无法自动登录
function Assert-Credentials {
    if ($txtAccount.Text.Trim() -eq '' -or $txtPassword.Text -eq '') {
        Append-Log '请先填写「账号」和「密码」。'
        $lblStatus.Text = '请先填写账号和密码'
        $lblStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        return $false
    }
    if (-not $chkRemember.Checked) {
        Append-Log '请勾选「记住账号密码（仅存本机）」——自动登录必须把凭据保存在本机。'
        $lblStatus.Text = '请勾选「记住账号密码」'
        $lblStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        return $false
    }
    return $true
}

# ---------------------- 事件绑定 ----------------------
$btnSave.Add_Click({
    try {
        Save-Config
        $msg = '配置已保存：账号 ' + $txtAccount.Text.Trim() + ' / 驱动 ' + $driverNames[$cbDriver.SelectedIndex]
        if (-not $chkRemember.Checked) { $msg += '（未勾选记住账号，自动登录将不可用）' }
        Append-Log $msg
        $lblStatus.Text = '配置已保存'
        $lblStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    } catch {
        Append-Log ('保存失败：' + $_.Exception.Message)
    }
})

$btnTest.Add_Click({
    if (-not (Assert-Credentials)) { return }
    Save-Config
    Start-PsFile -File $ScriptPath -ActionName '测试登录'
})

$btnInstall.Add_Click({
    if (-not (Assert-Credentials)) { return }
    Save-Config
    Start-PsFile -File $InstallPath -ActionName '安装/更新计划任务'
})

$btnUninstall.Add_Click({
    Start-PsFile -File $UninsPath -ActionName '卸载计划任务'
})

$btnOpenLog.Add_Click({
    if (Test-Path -LiteralPath $LogPath) { Start-Process -FilePath 'notepad.exe' -ArgumentList ('"' + $LogPath + '"') }
    else { Append-Log '暂无日志文件。' }
})

$btnOpenFolder.Add_Click({
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $Dir + '"')
})

# 启动时显示最近日志
if (Test-Path -LiteralPath $LogPath) {
    Append-Log '—— 最近日志 ——'
    $recent = Read-TextFile -Path $LogPath
    if ($recent) {
        $arr = @($recent -split "`r?`n" | Where-Object { $_ -ne '' })
        $tail = if ($arr.Count -gt 8) { $arr[($arr.Count - 8)..($arr.Count - 1)] } else { $arr }
        Append-Log ($tail -join "`r`n")
    }
}

# ---------------------- 显示 ----------------------
if ($SelfTest) {
    $tmp = Join-Path $env:TEMP 'campus-gui-selftest.psd1'
    Save-Config -Path $tmp
    $chk = Import-PowerShellDataFile -LiteralPath $tmp
    Write-Output ('GUI 自检成功：控件 ' + $form.Controls.Count + '，驱动 ' + $driverNames.Count +
                  '，配置回读 account=' + $chk.account + ' carrier=' + $chk.carrier + ' driver=' + $chk.driver +
                  ' ports=[' + (@($chk.portalPorts) -join ',') + ']')
    Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
    $form.Dispose()
    exit 0
}

[void]$form.ShowDialog()
$form.Dispose()
