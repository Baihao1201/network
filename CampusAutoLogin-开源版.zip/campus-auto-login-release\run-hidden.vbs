' ============================================================
'  Campus network auto-login - hidden launcher
'  Starts campus-login.ps1 with a hidden window.
'  "On Error Resume Next": even on failure, never show any dialog.
' ============================================================
On Error Resume Next

Dim fso, shell, dir, ps1, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = dir & "\campus-login.ps1"

If fso.FileExists(ps1) Then
    cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -NonInteractive -WindowStyle Hidden -File """ & ps1 & """"
    Set shell = CreateObject("WScript.Shell")
    shell.Run cmd, 0, False
End If
