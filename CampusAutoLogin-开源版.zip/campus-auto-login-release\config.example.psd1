# ============================================================
#  校园网自动登录 - 配置模板
# ------------------------------------------------------------
#  用法：把本文件复制为 config.psd1，然后填写你自己的信息。
#        （config.psd1 已被 .gitignore 忽略，不会误传到 GitHub）
# ============================================================
@{
    # -------- 账号信息（必改）--------
    account  = '你的学号'        # 学号 / 上网账号
    password = '你的密码'        # 上网密码
    carrier  = 'unicom'          # unicom=联通  mobile=移动  telecom=电信  campus=校园网

    # -------- 认证驱动 --------
    # 'snnu'    = 陕西师范大学（已内置）
    # 'generic' = 通用表单模板（改 drivers\generic.psd1 适配你学校）
    driver = 'snnu'

    # -------- 可选覆盖（留空 = 用驱动默认值）--------
    portalHost  = ''
    portalPorts = @()

    # -------- 外网判断参数 --------
    internetProbeIps = @('223.5.5.5', '223.6.6.6')
    internetTargets  = @('https://www.baidu.com', 'https://www.taobao.com')

    # -------- 时间参数 --------
    waitReadySec       = 45
    tcpTimeoutMs       = 500
    internetTimeoutSec = 4
    portalTimeoutSec   = 6
    loginRetryDelayMs  = 1500
}
