﻿<#
=====================================================================
 校园网 自动登录脚本（通用 / 驱动式）
 --------------------------------------------------------------------
 配置  ：config.psd1                （账号、密码、运营商、驱动、时间参数）
 驱动  ：drivers\<名称>.psd1        （描述某个学校门户"长什么样、怎么登录"）
 日志  ：logs\campus-login.log
 --------------------------------------------------------------------
 特点：
   · 用 .NET TCP 探测判断网络状态（不依赖 DNS、无外部进程、毫秒级）
     —— 刚连上 WiFi 时也能在 1 秒左右完成认证
   · 认证流程全部由"驱动"描述，换学校只需换驱动，不用改脚本
   · 以"能否真的上外网"作为唯一成功标准
 --------------------------------------------------------------------
 手动运行：
   powershell -NoProfile -ExecutionPolicy Bypass -File "本脚本"
 强制断开并重新登录（排查用）：
   powershell -NoProfile -ExecutionPolicy Bypass -File "本脚本" -ForceLogin
=====================================================================
#>
[CmdletBinding()]
param(
    [switch]$ForceLogin
)

# ===================== 默认配置（会被 config.psd1 覆盖）=====================
$defaults = @{
    account            = ''
    password           = ''
    carrier            = 'unicom'
    driver             = 'snnu'
    portalHost         = ''
    portalPorts        = @()
    internetProbeIps   = @('223.5.5.5', '223.6.6.6')
    internetTargets    = @('https://www.baidu.com', 'https://www.taobao.com')
    waitReadySec       = 45
    tcpTimeoutMs       = 500
    internetTimeoutSec = 4
    portalTimeoutSec   = 6
    loginRetryDelayMs  = 1500
}

# 内置兜底驱动（drivers\snnu.psd1 缺失时使用）
$builtinDriver = @{
    name        = 'snnu'
    displayName = '陕西师范大学（内置）'
    probeHost   = '202.117.144.205'
    probePorts  = @(8603, 8602, 8601)
    carriers    = @{ unicom = 'unicom'; mobile = 'mobile'; telecom = 'telecom'; campus = '' }
    login       = @{
        urlTemplate = 'http://{host}:{port}/snnuportal/login'
        method      = 'POST'
        fields      = @{ sourceurl = 'null'; account = '{account}'; password = '{password}'; yys = '{carrier}'; issave = '' }
    }
    logoff      = @{ urlTemplate = 'http://{host}:{port}/snnuportal/logoff'; method = 'POST' }
}
# ==========================================================================

$ScriptDir  = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$ConfigPath = Join-Path $ScriptDir 'config.psd1'
$DriversDir = Join-Path $ScriptDir 'drivers'
$LogDir     = Join-Path $ScriptDir 'logs'
$LogFile    = Join-Path $LogDir 'campus-login.log'

# ---------------------- 读取配置 ----------------------
$cfg = @{}
foreach ($k in $defaults.Keys) { $cfg[$k] = $defaults[$k] }
$configError = $null
if (Test-Path -LiteralPath $ConfigPath) {
    try {
        $userCfg = Import-PowerShellDataFile -LiteralPath $ConfigPath -ErrorAction Stop
        if ($userCfg) { foreach ($k in $userCfg.Keys) { $cfg[$k] = $userCfg[$k] } }
    } catch {
        $configError = $_.Exception.Message
    }
}

# ---------------------- 读取驱动 ----------------------
$driver = $null
$driverNote = ''
$driverPath = Join-Path $DriversDir ("{0}.psd1" -f $cfg.driver)
if (Test-Path -LiteralPath $driverPath) {
    try { $driver = Import-PowerShellDataFile -LiteralPath $driverPath -ErrorAction Stop }
    catch { $driver = $null; $driverNote = ('驱动读取失败: ' + $_.Exception.Message) }
}
if (-not $driver) {
    $driver = $builtinDriver
    if (-not $driverNote) { $driverNote = ('未找到驱动 {0}.psd1，使用内置 SNNU 驱动' -f $cfg.driver) }
}

# ---------------------- 解析目标主机 / 端口 / 运营商 ----------------------
$PortalHost = if ("$($cfg.portalHost)" -ne '') { [string]$cfg.portalHost } else { [string]$driver.probeHost }
$PortalPorts = @()
if (@($cfg.portalPorts).Count -gt 0) { $PortalPorts = @($cfg.portalPorts) } else { $PortalPorts = @($driver.probePorts) }
if (-not $PortalHost) { $PortalHost = '202.117.144.205' }
if ($PortalPorts.Count -eq 0) { $PortalPorts = @(80) }

$CarrierVal = [string]$cfg.carrier
if ($driver.carriers -and $driver.carriers.ContainsKey([string]$cfg.carrier)) {
    $CarrierVal = [string]$driver.carriers[[string]$cfg.carrier]
}

$script:HasCurl = [bool](Get-Command curl.exe -ErrorAction SilentlyContinue)

# ---------------------- 日志 ----------------------
function Write-Log {
    param([string]$Msg)
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Msg
    try {
        if (-not (Test-Path -LiteralPath $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
        if ((Test-Path -LiteralPath $LogFile) -and ((Get-Item -LiteralPath $LogFile).Length -gt 524288)) {
            $tail = Get-Content -LiteralPath $LogFile -Tail 200 -Encoding UTF8
            Set-Content -LiteralPath $LogFile -Value $tail -Encoding UTF8
        }
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    } catch { }
    Write-Output $line
}

# ---------------------- 网络探测（.NET，毫秒级，不依赖 DNS）----------------------
function Test-TcpPort {
    param([string]$ComputerName, [int]$Port, [int]$TimeoutMs = 500)
    if (-not $ComputerName -or $Port -le 0) { return $false }
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($ComputerName, $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) { return $false }
        $client.EndConnect($iar)
        return $true
    } catch {
        return $false
    } finally {
        try { $client.Close() } catch { }
    }
}

# 是否存在"已连接"的物理网卡（排除 VMware / VPN 等虚拟网卡）
function Test-PhysicalUp {
    try {
        $n = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
        return ($n.Count -gt 0)
    } catch { return $true }
}

# 快速外网探测：TCP 连公网 IP 的 443（在线时约 25ms；离线时最多 timeoutMs×N）
function Test-NetFast {
    param([int]$MaxIps = 0)
    $list = @($cfg.internetProbeIps)
    if ($MaxIps -gt 0 -and $list.Count -gt $MaxIps) { $list = $list[0..($MaxIps - 1)] }
    foreach ($ip in $list) {
        if (Test-TcpPort -ComputerName "$ip" -Port 443 -TimeoutMs ([int]$cfg.tcpTimeoutMs)) { return $true }
    }
    return $false
}

# 精确外网确认：HTTP 打开任一目标返回 200/204（不跟随跳转，避免被门户重定向骗过）
function Test-NetHttp {
    foreach ($t in @($cfg.internetTargets)) {
        if ($script:HasCurl) {
            $out = & curl.exe -s -o NUL -w '%{http_code}' --connect-timeout 3 --max-time ([int]$cfg.internetTimeoutSec) $t 2>$null
            if ("$out" -eq '200' -or "$out" -eq '204') { return $true }
        } else {
            try {
                [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                $r = Invoke-WebRequest -Uri $t -UseBasicParsing -TimeoutSec ([int]$cfg.internetTimeoutSec) -ErrorAction Stop
                if ([int]$r.StatusCode -eq 200 -or [int]$r.StatusCode -eq 204) { return $true }
            } catch { }
        }
    }
    return $false
}

# 权威"已在线"判定：先快后准，离线时不会卡在 DNS 上
function Test-Online {
    param([switch]$Quick)
    if (-not (Test-NetFast -MaxIps $(if ($Quick) { 1 } else { 0 }))) { return $false }
    return (Test-NetHttp)
}

# ---------------------- 模板与请求 ----------------------
function Expand-Tpl {
    param([string]$Tpl, [hashtable]$Vars)
    if ($null -eq $Tpl) { return '' }
    $s = [string]$Tpl
    foreach ($k in $Vars.Keys) { $s = $s.Replace('{' + $k + '}', [string]$Vars[$k]) }
    return $s
}

function New-Vars {
    param([int]$Port)
    return @{
        host     = $PortalHost
        port     = $Port
        account  = [string]$cfg.account
        password = [string]$cfg.password
        carrier  = $CarrierVal
    }
}

# 门户端口是否可达（TCP）
function Get-ReachablePort {
    foreach ($p in $PortalPorts) {
        if (Test-TcpPort -ComputerName $PortalHost -Port ([int]$p) -TimeoutMs ([int]$cfg.tcpTimeoutMs)) { return [int]$p }
    }
    return 0
}

# 发送登录/断开请求；返回 $true = 服务器有响应（请求已送达）
function Invoke-PortalRequest {
    param([string]$UrlTemplate, [string]$Method, $Fields, [int]$Port)
    $vars = New-Vars -Port $Port
    $url  = Expand-Tpl -Tpl $UrlTemplate -Vars $vars
    if (-not $url) { return $false }

    $data = @{}
    if ($Fields) { foreach ($k in $Fields.Keys) { $data[$k] = Expand-Tpl -Tpl ([string]$Fields[$k]) -Vars $vars } }

    if ($script:HasCurl) {
        $pairs = @()
        foreach ($k in $data.Keys) {
            $pairs += ('{0}={1}' -f [uri]::EscapeDataString([string]$k), [uri]::EscapeDataString([string]$data[$k]))
        }
        $body = $pairs -join '&'
        if ("$Method".ToUpper() -eq 'GET' -and $body) {
            $out = & curl.exe -s -o NUL -w '%{http_code}' --connect-timeout 3 --max-time ([int]$cfg.portalTimeoutSec) ($url + '?' + $body) 2>$null
        } else {
            $out = & curl.exe -s -o NUL -w '%{http_code}' -X "$Method" --data $body --connect-timeout 3 --max-time ([int]$cfg.portalTimeoutSec) $url 2>$null
        }
        $code = "$out".Trim()
        return ($code -match '^\d{3}$' -and $code -ne '000')
    }

    try {
        $p = @{ Uri = $url; Method = $Method; UseBasicParsing = $true; TimeoutSec = [int]$cfg.portalTimeoutSec; ErrorAction = 'Stop' }
        if ($data.Count -gt 0) { $p['Body'] = $data }
        $null = Invoke-WebRequest @p
        return $true
    } catch {
        return ($null -ne $_.Exception.Response)
    }
}

# ===================== 主逻辑 =====================
if ($configError) { Write-Log ("警告：config.psd1 读取失败，已使用默认配置（{0}）" -f $configError) }
if ($driverNote)  { Write-Log ("提示：{0}" -f $driverNote) }
Write-Log ("开始检测（账号 {0} / 驱动 {1} / 门户 {2}:{3}）" -f $cfg.account, $driver.name, $PortalHost, ($PortalPorts -join ','))

if (-not $cfg.account -or -not $cfg.password) {
    Write-Log '错误：config.psd1 里没有填写 account / password，已退出。'
    exit 2
}

# 1) 已经能上网 → 直接退出（用快速探测，在线时约几十毫秒）
if ((-not $ForceLogin) -and (Test-Online -Quick)) {
    Write-Log '外网正常，已在线，无需重连。'
    exit 0
}

# 2) 持续尝试：一旦门户可达就立即登录；登录后用"能否上外网"校验
$startTime   = Get-Date
$deadline    = $startTime.AddSeconds([int]$cfg.waitReadySec)
$lastAttempt = [datetime]::MinValue
$attempts    = 0
$done        = $false
$loggedOff   = $false

while (-not $done -and (Get-Date) -lt $deadline) {

    # 若已运行几秒、却连一块"已连接"的物理网卡都没有，说明网络根本不通，
    # 没必要继续占着内存空转，直接退出等下一次网络事件
    if (((Get-Date) - $startTime).TotalSeconds -ge 3 -and -not (Test-PhysicalUp)) {
        Write-Log '未检测到已连接的网络接口，退出（等下次网络事件）。'
        break
    }

    $port = Get-ReachablePort
    $due  = (((Get-Date) - $lastAttempt).TotalMilliseconds -ge [int]$cfg.loginRetryDelayMs)

    if ($port -gt 0 -and $due) {
        $lastAttempt = Get-Date
        $attempts++

        if ($ForceLogin -and -not $loggedOff) {
            Write-Log ("强制登录：先断开连接 (端口 {0}) ..." -f $port)
            if ($driver.logoff) { $null = Invoke-PortalRequest -UrlTemplate $driver.logoff.urlTemplate -Method $driver.logoff.method -Fields $null -Port $port }
            $loggedOff = $true
            Start-Sleep -Milliseconds 800
        }

        Write-Log ("正在登录校园网 (端口 {0}, 第 {1} 次) ..." -f $port, $attempts)
        $ok = $false
        if ($driver.login) {
            $ok = Invoke-PortalRequest -UrlTemplate $driver.login.urlTemplate -Method $driver.login.method -Fields $driver.login.fields -Port $port
        }
        if (-not $ok) {
            Write-Log '登录请求未送达，稍后重试...'
        } else {
            # 登录后校验：外网是否真的恢复（快速探测，最多 ~6 秒）
            for ($i = 0; $i -lt 12; $i++) {
                Start-Sleep -Milliseconds 500
                if (Test-NetFast -MaxIps 1) { $done = $true; break }
            }
            if ($done) { Write-Log ("登录成功，外网已恢复 (端口 {0})。" -f $port) }
            else { Write-Log '已提交登录，外网尚未恢复，继续尝试...' }
        }
    }
    elseif (-not $ForceLogin -and (Test-Online -Quick)) {
        # 门户不可达（可能不在校园网）或登录节流中：顺手确认一下是否已经能上网
        Write-Log '外网正常，已在线。'
        $done = $true
        break
    }

    if (-not $done) { Start-Sleep -Milliseconds 250 }
}

# 3) 结果
if ($done -or (Test-Online)) {
    Write-Log '结果：外网已连接。'
    exit 0
}
Write-Log ("结果：未能连接外网（已尝试 {0} 次）。" -f $attempts)
exit 1
